# ZM Business Alliance — Netlify Fixed Package

## What was fixed
- Fixed the Netlify Blobs store configuration so it supports Netlify's automatic runtime credentials and explicit environment credentials when needed.
- Fixed admin authentication to require both `ADMIN_PASSWORD` and `ADMIN_SESSION_SECRET`.
- Added real persistent image uploads using a separate Netlify Blobs store.
- Added logo upload/editing in the admin panel.
- Made the public homepage load editable settings, services, jobs, posters/images, logo, phone, email and Instagram from the admin data.
- Existing supplied logo/posters remain in `assets/` as fallback/default content.

## Netlify setup
1. Deploy this ZIP as the site source (do not upload only individual files).
2. In Netlify, open **Project configuration → Environment variables**.
3. Add:
   - `ADMIN_PASSWORD` = your private admin password
   - `ADMIN_SESSION_SECRET` = a random secret of 32+ characters
4. If the Blobs error still appears after deployment, add these two environment variables too:
   - `NETLIFY_SITE_ID` = your Netlify site ID
   - `NETLIFY_AUTH_TOKEN` = a Netlify personal access token with access to the site
5. Redeploy after changing environment variables.
6. Open `/admin.html`, log in, and edit/save the site.
7. Use the new **Logo** and **Photo / Poster Manager** controls to upload images. Maximum upload size is 5 MB per image.

## Important
Never put `NETLIFY_AUTH_TOKEN`, `ADMIN_PASSWORD`, or `ADMIN_SESSION_SECRET` into `index.html`, `admin.html`, or any frontend JavaScript.

## Added posters
The 10 newly supplied posters are bundled under `assets/poster-01.png` through `assets/poster-10.png` and are automatically added to the public poster/insights section, including on deployments that already have older poster data in Netlify Blobs.
