const crypto = require("crypto");
const { getStore } = require("@netlify/blobs");

const BUILTIN_POSTERS = [
    {url:"assets/poster-01.png",caption:"Canada Esponsor Base Visa"},
    {url:"assets/poster-02.png",caption:"Greece Open Work Permit — Medical Batch"},
    {url:"assets/poster-03.png",caption:"Japan Sure Shot Visa"},
    {url:"assets/poster-04.png",caption:"Greece Schengen — 9 Month Open Work Permit"},
    {url:"assets/poster-05.png",caption:"Canada Work Permit — 2 Year"},
    {url:"assets/poster-06.png",caption:"B2B Visa Filing — Global Destinations"},
    {url:"assets/poster-07.png",caption:"ZM Business Alliance — We Are Hiring"},
    {url:"assets/poster-08.png",caption:"UAE Security Guard — Urgent Requirement"},
    {url:"assets/poster-09.png",caption:"Professional Website Package — AED 699"},
    {url:"assets/poster-10.png",caption:"Job Vacancy — Car Washer"}
];

const DEFAULTS = {
  companyName:"ZM Business Alliance",
  heroHeading:"YOUR BUSINESS, OUR NETWORK, GLOBAL IMPACT.",
  heroDescription:"Connecting businesses across India, UAE, and 40+ countries worldwide.",
  phone:"+91 8398802971",
  email:"zmbusinessalliance@gmail.com",
  instagram:"zmbusinessalliance",
  countries:"40+",
  partners:"500+",
  logo:"assets/zm-logo.png",
  services:[
    {title:"Recruitment Solutions",description:"Connecting the right talent with the right opportunities — permanent, temporary and contract staffing."},
    {title:"Manpower Supply",description:"Skilled, semi-skilled and unskilled manpower for varied industries and business needs."},
    {title:"Digital Solutions",description:"Website development, branding, social media marketing, SEO and complete digital growth solutions."},
    {title:"Business Consultancy",description:"Strategy, planning, setup, operations and process improvement support."},
    {title:"Documentation Services",description:"PRO services, visa processing, company setup support, typing, attestation and document clearing."},
    {title:"Branding & Marketing",description:"Creative design, marketing campaigns and digital promotion to build stronger brands."}
  ],
  jobs:[
    {title:"Housemaid",description:"Cleaning, dusting and organizing."},
    {title:"Home Nurse",description:"Patient care, elderly assistance and medical needs."},
    {title:"Male/Female Nurse",description:"Clinical nursing, medical support and various settings."}
  ],
  posts:[],
  images:[
    {url:"assets/who-we-are.png",caption:"Who We Are"},
    {url:"assets/work-with-us.png",caption:"Work With Us"},
    {url:"assets/our-services.png",caption:"Our Services"},
    {url:"assets/job-vacancy.png",caption:"Job Vacancy"},
    ...BUILTIN_POSTERS
  ]
};

function makeStore(name="zm-site-data"){
  const options={name,consistency:"strong"};
  // Netlify supplies these automatically in deployed Functions.
  // The explicit fallback also supports local/other runtimes.
  const siteID=process.env.NETLIFY_SITE_ID || process.env.SITE_ID;
  const token=process.env.NETLIFY_AUTH_TOKEN || process.env.NETLIFY_BLOBS_TOKEN;
  if(siteID && token){ options.siteID=siteID; options.token=token; }
  return getStore(options);
}

function secret(){return process.env.ADMIN_SESSION_SECRET || "";}
function password(){return process.env.ADMIN_PASSWORD || "";}

function sign(payload){
  const data=Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig=crypto.createHmac("sha256",secret()).update(data).digest("base64url");
  return data+"."+sig;
}

function verify(t){
  try{
    if(!t || !secret()) return null;
    const [data,sig]=t.split(".");
    if(!data||!sig)return null;
    const good=crypto.createHmac("sha256",secret()).update(data).digest("base64url");
    if(sig.length!==good.length || !crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(good)))return null;
    const p=JSON.parse(Buffer.from(data,"base64url").toString());
    return Date.now()<=p.exp ? p : null;
  }catch{return null;}
}

async function getData(){
  const store=makeStore();
  const x=await store.get("content",{type:"json"});
  if(!x) return DEFAULTS;
  // Keep newly bundled posters visible after redeploys, while preserving
  // anything already managed through the admin panel.
  const current=Array.isArray(x.images)?x.images:[];
  const existing=new Set(current.map(v=>v&&v.url).filter(Boolean));
  const missing=BUILTIN_POSTERS.filter(v=>!existing.has(v.url));
  return missing.length ? {...x,images:[...current,...missing]} : x;
}

async function saveData(patch){
  const store=makeStore();
  const old=await getData();
  const next={...old,...patch};
  await store.setJSON("content",next);
  return next;
}

function json(status,body,extra={}){
  return {statusCode:status,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*",...extra},body:JSON.stringify(body)};
}

exports.handler=async(event)=>{
  const headers={
    "Content-Type":"application/json",
    "Access-Control-Allow-Origin":"*",
    "Access-Control-Allow-Headers":"Content-Type, Authorization",
    "Access-Control-Allow-Methods":"POST, OPTIONS"
  };
  if(event.httpMethod==="OPTIONS")return{statusCode:204,headers};

  try{
    const body=event.body?JSON.parse(event.body):{};

    if(body.action==="login"){
      if(!password())return json(500,{ok:false,error:"ADMIN_PASSWORD is not configured in Netlify."},headers);
      if(body.password!==password())return json(401,{ok:false,error:"Invalid password."},headers);
      if(!secret())return json(500,{ok:false,error:"ADMIN_SESSION_SECRET is not configured in Netlify."},headers);
      const token=sign({exp:Date.now()+1000*60*60*8});
      return json(200,{ok:true,token},headers);
    }

    if(body.action==="public"){
      const data=await getData();
      return json(200,{ok:true,data},headers);
    }

    const auth=event.headers?.authorization||event.headers?.Authorization||"";
    if(!verify(auth.replace(/^Bearer\s+/i,"")))return json(401,{ok:false,error:"Unauthorized. Please login again."},headers);

    if(body.action==="get")return json(200,{ok:true,data:await getData()},headers);

    if(body.action==="save"){
      const allowed=["companyName","heroHeading","heroDescription","phone","email","instagram","countries","partners","logo","services","jobs","posts","images"];
      const patch={};
      for(const k of allowed)if(Object.prototype.hasOwnProperty.call(body.data||{},k))patch[k]=body.data[k];
      return json(200,{ok:true,data:await saveData(patch)},headers);
    }

    if(body.action==="upload"){
      const file=body.file||{};
      if(!file.name || !file.dataUrl)return json(400,{ok:false,error:"File data is missing."},headers);
      if(!/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(file.dataUrl)){
        return json(400,{ok:false,error:"Only PNG, JPG, WEBP and GIF images are allowed."},headers);
      }
      const m=file.dataUrl.match(/^data:(image\/[^;]+);base64,(.+)$/i);
      const buffer=Buffer.from(m[2],"base64");
      if(buffer.length>5*1024*1024)return json(413,{ok:false,error:"Image must be 5 MB or smaller."},headers);
      const safe=(file.name||"image").replace(/[^a-zA-Z0-9._-]/g,"-").toLowerCase();
      const key=`uploads/${Date.now()}-${safe}`;
      const store=makeStore("zm-site-images");
      await store.set(key,buffer,{metadata:{contentType:m[1]}});
      return json(200,{ok:true,url:`/.netlify/functions/admin-api?action=image&key=${encodeURIComponent(key)}`},headers);
    }

    if(body.action==="image"){
      const key=String(body.key||"");
      if(!key.startsWith("uploads/"))return json(400,{ok:false,error:"Invalid image key."},headers);
      const store=makeStore("zm-site-images");
      const data=await store.get(key,{type:"arrayBuffer"});
      if(!data)return json(404,{ok:false,error:"Image not found."},headers);
      return {
        statusCode:200,
        headers:{"Content-Type":"image/*","Cache-Control":"public, max-age=31536000, immutable","Access-Control-Allow-Origin":"*"},
        isBase64Encoded:true,
        body:Buffer.from(data).toString("base64")
      };
    }

    return json(400,{ok:false,error:"Unknown action."},headers);
  }catch(e){
    console.error(e);
    return json(500,{ok:false,error:e.message||"Server error."},headers);
  }
};
